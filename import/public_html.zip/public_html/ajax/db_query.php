<html>
    <head>
        <style>
            .point {margin: 20px auto;
    background: #d9f1e3;
    padding: 20px;text-align:center;display:flex;flex-direction: column;justify-content: center;width:fit-content;}
    .point label.angkapoin {background-color:#00ad5f;width:fit-content;padding:10px;margin:11px auto 0;color:#fff;letter-spacing:3px}
    .point b.poinanda {font-size:18px;margin-top:10px;}
    .point label.angkapoin {font-size:22px;font-weight:600;}
    .point h3 {font-size:22px;margin:0;text-transform:uppercase;}
    @media screen and (max-width: 992px) {
        .point {padding:50px;}
        .point h3 {font-size:34px;}
        .point b.poinanda {font-size:30px;margin-top:20px;}
        .point label.angkapoin {font-size:34px;font-weight:600;}
    }
    
        </style>
    </head>
    <body>
<?php

$username = "segeionl_rokim";
$password = "naldshhsd321";
$database = "segeionl_penjualan"; 

// Database Error - User Message
$msgerror = ('Could not connect!<br />Please contact the site\'s administrator.');

$conn = mysql_connect("localhost", $username, $password) or die($msgerror);

############## Make the mysql connection ###########

$db = mysql_select_db($database) or die($msgerror);


$member = mysql_query("
  SELECT * 
  FROM member 
  WHERE kode='".$_POST['value']."'
");

  $count = mysql_num_rows($member);
  if($count == "0"){
        echo '<h3>Nomor Anda Salah !</h3>';
    }else{

while ($data = mysql_fetch_array($member)) {
    
echo '<div class="point">';   

echo '<h3 class="nama">'; 
echo $data['nama'];
echo '</h3>';


}
}

?>


<?php 

$poin = mysql_query("
  SELECT * 
  FROM poin 
  WHERE no='".$_POST['value']."'
");

 $countt = mysql_num_rows($poin);
  if($countt == "0"){
        echo '';
    }else{


$sum = mysql_query("SELECT SUM(poin) AS total FROM `poin` WHERE no='".$_POST['value']."'") or die(mysql_error());


					$fetch = mysql_fetch_array($sum) ;
					
					if($fetch == "0"){
        echo '';
    }else{
				echo '<b class="poinanda">Poin Anda</b><label class="angkapoin">' ;
			echo $fetch['total'];
			echo '</label>';
			echo '</div>';
    }
    }
			?>
			
	</body>
	</html>