<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html lang="id" dir="ltr">

  <head>

    <title>Cek Point Member - Green Baby Shop</title>

    <meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=ISO-8859-1">
    <meta http-equiv="Content-Style-Type" content="text/css">
<link href='manifest.json' rel='manifest'/>
    <!-- JQUERY FROM GOOGLE API -->
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

    <script type="text/javascript">
      $(function() {
        $("#lets_search").bind('submit',function() {
          var value = $('#str').val();
           $.post('db_query.php',{value:value}, function(data){
             $("#search_results").html(data);
           });
           return false;
        });
      });
    </script>
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet" />
    
    <style>
    body {background:#fff;}
        .frame {max-width:800px;width:100%;margin:0 auto;padding:20px;}
        input,
button {
  font-family: 'Poppins', sans-serif;
}

* {
  box-sizing: border-box;
}
input:-webkit-autofill,
input:-webkit-autofill:hover, 
input:-webkit-autofill:focus,
textarea:-webkit-autofill,
textarea:-webkit-autofill:hover,
textarea:-webkit-autofill:focus,
select:-webkit-autofill,
select:-webkit-autofill:hover,
select:-webkit-autofill:focus {
  -webkit-box-shadow: 0 0 0px 1000px #d9f1e3 inset;
  transition: background-color 5000s ease-in-out 0s;
}
.s130 {
  min-height: 90vh;
  -ms-flex-pack: center;
      justify-content: center;
  font-family: 'Poppins', sans-serif;
  background: url("../images/Searchs_130.png");
  background-position: bottom right;
  background-repeat: no-repeat;
  background-size: 100%;
  padding: 15px;
  width: 100%;
    max-width: 1000px;
    margin: 0 auto;
    display:flex;
    flex-direction: column;
}

.s130 form {
  width: 100%;
  margin:0 auto;
}

.s130 form .inner-form {
  display: -ms-flexbox;
  display: flex;
  width: 100%;
  -ms-flex-pack: justify;
      justify-content: space-between;
  -ms-flex-align: center;
      align-items: center;
  box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  border-radius: 134px;
  overflow: hidden;
  margin-bottom: 30px;
  border: 1px solid #dfe1e5;
}

.s130 form .inner-form .input-field {
  height: 68px;
}

.s130 form .inner-form .input-field input {
  height: 100%;
  background: transparent;
  border: 0;
  display: block;
  width: 100%;
  padding: 10px 0;
  font-size: 15px;
  color: #000;
}

.s130 form .inner-form .input-field input.placeholder {
  color: #222;
  font-size: 16px;
}

.s130 form .inner-form .input-field input:-moz-placeholder {
  color: #222;
  font-size: 16px;
}

.s130 form .inner-form .input-field input::-webkit-input-placeholder {
  color: #222;
  font-size: 16px;
}

.s130 form .inner-form .input-field input:hover, .s130 form .inner-form .input-field input:focus {
  box-shadow: none;
  outline: 0;
}

.s130 form .inner-form .input-field.first-wrap {
  -ms-flex-positive: 1;
      flex-grow: 1;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-align: center;
      align-items: center;
      background: #d9f1e3;
}

.s130 form .inner-form .input-field.first-wrap input {
  -ms-flex-positive: 1;
      flex-grow: 1;
}

.s130 form .inner-form .input-field.first-wrap .svg-wrapper {
  min-width: 80px;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-pack: center;
      justify-content: center;
  -ms-flex-align: center;
      align-items: center;
}

.s130 form .inner-form .input-field.first-wrap svg {
  width: 36px;
  height: 36px;
  fill: #222;
}

.s130 form .inner-form .input-field.second-wrap {
  min-width: 216px;
  background: #00ad5f;
}

.s130 form .inner-form .input-field.second-wrap input {
       font-weight: 600;
  cursor: pointer;
  letter-spacing:2px;
  color:#fff;
}

.s130 form .inner-form .input-field.second-wrap .btn-search {
  height: 100%;
  width: 100%;
  white-space: nowrap;
  font-size: 16px;
  color: #fff;
  border: 0;
  cursor: pointer;
  position: relative;
  z-index: 0;
  background: #00ad5f;
  transition: all .2s ease-out, color .2s ease-out;
  font-weight: 300;
}



.s130 form .inner-form .input-field.second-wrap .btn-search:focus {
  outline: 0;
  box-shadow: none;
}

.s130 form .info {
  font-size: 15px;
  color: #ccc;
  padding-left: 26px;
}
    
.header {text-align:center;
    margin-bottom:20px;
    
}
.header h1 {text-transform: uppercase;font-size:28px;margin:0;}
.header p {margin:0 0 10px;font-weight:600;}



@media screen and (max-width: 992px) {
  .s130 form .inner-form .input-field {
    height: 120px;
    font-size:30px;
  }
 .s130 form .inner-form .input-field input {font-size:32px;
 }
 .s130 form .inner-form .input-field input::-webkit-input-placeholder{
	font-size:32px;
}
.s130 form .inner-form .input-field.first-wrap svg {
    width: 66px!important;
    height: 66px!important;
    fill: #222;
  }
  .s130 form .inner-form .input-field.first-wrap .svg-wrapper {
  margin: 0 5px 0 20px;
  }
  .header h1 {font-size:34px;}
.header p {font-size:20px;}
}

@media screen and (max-width: 767px) {
  .s130 form .inner-form .input-field.first-wrap .svg-wrapper {
    min-width: 120px;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-pack: center;
        justify-content: center;
    -ms-flex-align: center;
        align-items: center;
    padding: 0 10px;
  }
  .s130 form .inner-form .input-field.first-wrap svg {
    width: 46px!important;
    height: 46px!important;
    fill: #222;
  }
  .s130 form .inner-form .input-field.second-wrap {
    min-width: 100px;
  }
  .s130 form .inner-form .input-field.second-wrap .btn-search {
    font-size: 13px;
  }
}
    </style>

  </head>

  <body>
      <div class="s130">
          <div class="header">
                <h1>Cek Point - Green Baby Shop</h1>
                <p class="deskripsi">Silahkan masukkan nomor hp anda pada kolom di bawah ini.</p>
          </div>
        
      <form id="lets_search" action="">
          <div class="inner-form">
          <div class="input-field first-wrap">
            <div class="svg-wrapper">
              <svg xmlns="http://www.w3.org/2000/svg" width="54" height="54" viewBox="0 0 24 24">
                <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
              </svg>
            </div>
        <input type="text" name="str" id="str" placeholder="Masukkan no hp anda...">
        </div>
          <div class="input-field second-wrap">
              
              
            
        <input type="submit" value="LIHAT" name="send" id="send">
        </div>
        </div>
      </form>
      <div id="search_results"></div>
</div>
  </body>

</html>