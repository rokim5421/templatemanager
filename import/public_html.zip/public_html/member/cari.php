<?php
include('koneksi.php');
// php code to search data in mysql database and set it in input text

if(isset($_POST['search']))
{
    // id to search
    $id = $_POST['id'];
    
    // mysql search query
    $query = "SELECT `id`, `nama`, `alamat`, `telepon` FROM `data_pegawai` WHERE `id` = $id LIMIT 1";
    
    $result = mysql_query($query);
    
    // if id exist 
    // show data in inputs
    if(mysql_num_rows($result) > 0)
    {
      while ($row = mysql_fetch_array($result))
      {
        $fname = $row['id'];
        $lname = $row['nama'];
        $alamat = $row['alamat'];
        $telepon = $row['telepon'];
      }  
    }
    
    // if the id not exist
    // show a message and clear inputs
    else {
        echo "Undifined ID";
            $fname = "";
            $lname = "";
            $age = "";
    }
    
    
    mysql_free_result($result);
    mysql_close();
    
}

// in the first time inputs are empty
else{
    $fname = "";
    $lname = "";
    $age = "";
}


?>

<!DOCTYPE html>

<html>

    <head>

        <title> PHP FIND DATA </title>

        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>

    <form action="/" method="post">

        Id:<input type="text" name="id"><br><br>

        First Name:<input type="text" name="fname" value="<?php echo $fname;?>"><br>
<br>

        Last Name:<input type="text" name="lname" value="<?php echo $lname;?>"><br><br>

        Age:<input type="text" name="age" value="<?php echo $alamat;?>"><br><br>

        <input type="submit" name="search" value="Find">

           </form>

    </body>

</html>