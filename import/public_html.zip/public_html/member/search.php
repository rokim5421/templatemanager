<?php
include_once('koneksi.php');
if(isset($_POST['search'])){
    $q = $_POST['q'];
    $query = mysql_query("SELECT * FROM data_pegawai WHERE id LIKE '%$qname%'"); 


    $count = mysql_num_rows($query);
    if($count == "0"){
        $output = '<h2>No result found!</h2>';
    }else{
        while($row = mysql_fetch_array($query)){
        $s = $row['id']; 
                $output .= '<div><p>'.$s.'</div></p>';
            }
        }
    }
?>

        <form method="POST" action="search.php">
            <input type="text" name="q" placeholder="query">
            <input type="submit" name="search" value="Search">
        </form>
        <?php echo $output; ?>