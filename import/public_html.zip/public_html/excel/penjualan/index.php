<!DOCTYPE html>
<html>
<head>
	<title>Import Excel Ke MySQL dengan PHP - www.malasngoding.com</title>
</head>
<body>
	<style type="text/css">
		body{
			font-family: sans-serif;
		}

		p{
			color: green;
		}
	</style>



<?php 
// menghubungkan dengan koneksi
include 'koneksi.php';
// menghubungkan dengan library excel reader
include "excel_reader2.php";
$_FILESSS = "contoh.xls";
?>

<?php

//$hapus = "DELETE FROM data_pegawai";
   //$sql = mysql_query ($hapus);
        
// upload file xls
$target = basename($_FILESSS) ;
move_uploaded_file($_FILESSS, $target);

// beri permisi agar file xls dapat di baca
chmod($_FILESSS,0777);

// mengambil isi file xls
$data = new Spreadsheet_Excel_Reader($_FILESSS,false);
// menghitung jumlah baris data yang ada
$jumlah_baris = $data->rowcount($sheet_index=0);

// jumlah default data yang berhasil di import
$berhasil = 0;
for ($i=2; $i<=$jumlah_baris; $i++){

	// menangkap data dan memasukkan ke variabel sesuai dengan kolumnya masing-masing
	$nama     = $data->val($i, 1);
	$alamat   = $data->val($i, 2);
	$telepon  = $data->val($i, 3);

	if($nama != "" && $alamat != "" && $telepon != ""){

	    
	    mysql_query("INSERT into data_pegawai (Nama, ALamat, Telepon)
SELECT * FROM (SELECT '$nama', '$alamat', '$telepon') AS tmp
WHERE NOT EXISTS (
    SELECT Nama FROM data_pegawai WHERE Nama = '$nama'
) LIMIT 1;

");


	    
		// input data ke database (table data_pegawai)
	//	mysql_query("INSERT into data_pegawai values('','$nama','$alamat'//,'$telepon')");
		$berhasil++;
	}
}

?>
	<table border="1">
		<tr>
			<th>No</th>
			<th>Nama</th>
			<th>ALamat</th>
			<th>Telepon</th>
		</tr>
		<?php 
		include 'koneksi.php';
		$no=1;
		$data = mysql_query("select * from data_pegawai");
		while($d = mysql_fetch_array($data)){
			?>
			<tr>
				<th><?php echo $no++; ?></th>
				<th><?php echo $d['nama']; ?></th>
				<th><?php echo $d['alamat']; ?></th>
				<th><?php echo $d['telepon']; ?></th>
			</tr>
			<?php 
		}
		?>

	</table>
	<?php $sum = mysql_query("SELECT SUM(telepon) AS total FROM `data_pegawai`") or die(mysql_error());
					$fetch = mysql_fetch_array($sum);
			?>
			<br />
<b>Total = </b><label><?php echo $fetch['total']?></label>
</body>
</html>