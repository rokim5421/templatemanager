<!DOCTYPE html>
<html>
<head>
	<title>Import Excel Ke MySQL dengan PHP - www.malasngoding.com</title>
</head>
<body>
	<style type="text/css">
		body{
			font-family: sans-serif;
		}

		p{
			color: green;
		}
	</style>
		<?php 
		include 'koneksi.php';
		?>

<a href="/excel/penjualan"><button>
        Penjualan</button></a>


</body>
</html>