<?php 
$username = "segeionl_rokim";
$password = "naldshhsd321";
$database = "segeionl_penjualan"; 
mysql_connect("localhost", $username, $password);
mysql_select_db($database);
 
$file = "contoh.csv";
$handle = fopen($file,"r");
 
while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
    $query ="INSERT INTO contoh VALUES 
                (
                 NULL,
                 '".addslashes($data[0])."',
                 '".addslashes($data[1])."',        
                 '".addslashes($data[2])."'
                 )
    ";
    echo "< pre>";
    print_r ($query);
    echo "</ pre>";
    $hasil = mysql_query($query);
}
?>