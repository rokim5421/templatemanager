<?php 
$username = "segeionl_rokim";
$password = "naldshhsd321";
$database = "segeionl_penjualan"; 
mysql_connect("localhost", $username, $password);
mysql_select_db($database);

$hapus = "DELETE FROM contoh";
        $sql = mysql_query ($hapus);
?>