<?php
if (($handle = fopen("contoh.csv", "r")) !== FALSE) {
      while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        for ($c=0; $c < $num; $c++) {
           echo $data[$c] . "<br/>";
        }
    }
}
?>