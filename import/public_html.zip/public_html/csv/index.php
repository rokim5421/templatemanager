<html>
    <head>
        <style>
            .button {
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  background-color: #4CAF50;
}
        </style>
    </head>
    <body>
<a href="http://segerabeli.online/csv/penjualan"><button class="button button1">Penjualan</button></a>
    </body>
</html>